class Task {
  public:
    Task(void (*aCallback)()) {};
};

