// This file *is* included from the main sketch, even though it is
// outside of the src/ directory.
