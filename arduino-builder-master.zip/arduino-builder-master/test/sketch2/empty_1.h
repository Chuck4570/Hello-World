#define world

void two() {
}