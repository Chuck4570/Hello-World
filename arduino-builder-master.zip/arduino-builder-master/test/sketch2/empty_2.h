#define hello

void one(MyType arg){
}