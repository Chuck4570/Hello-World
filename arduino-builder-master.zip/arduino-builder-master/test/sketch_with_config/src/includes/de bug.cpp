#pragma debug

void debug() {
    //add debug code
}