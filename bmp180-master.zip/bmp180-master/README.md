A T.A.P (Temperature/Altitude/Pressure) display based on Arduino, BMP180, and a Nokia 5110 LCD module.

![BMP180 Schematic](circuit.png "BMP180 Schematic")
<br />
<br />