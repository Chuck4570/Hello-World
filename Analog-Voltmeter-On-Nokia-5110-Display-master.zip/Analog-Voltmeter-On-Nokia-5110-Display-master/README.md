# Analog-Voltmeter-On-Nokia-5110-Display
Make your Own Multimeter usinng arduino

copy code from Arduino Multimeter
Varify / Upload
Use pull down ressistor of (10k-100k) in between analog input and ground
twaek with contrast and update rate of lcd

